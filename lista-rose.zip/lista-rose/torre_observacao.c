#include <stdio.h>
#include <stdlib.h>

#define MAX_ROWS 102
#define MAX_COLS 102
#define MAX_TOWERS 102

void count_visible_areas(int N, int M, char terrain[N][M], int T, int towers[], int *visible_areas, char visible_terrain[N][M]) {
    *visible_areas = 0;

    for (int t = 0; t < T; t++) {
        int height = towers[t];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < M; j++) {
                if (terrain[i][j] == 't') {
                    for (int x = i - height; x <= i + height; x++) {
                        if (x < 0 || x >= N) continue;
                        for (int y = j - height; y <= j + height; y++) {
                            if (y < 0 || y >= M) continue;
                            if (abs(x - i) + abs(y - j) <= height && visible_terrain[x][y] == '#') {
                                (*visible_areas)++;
                                visible_terrain[x][y] = '.';
                            }
                        }
                    }
                }
            }
        }
    }
}

int main() {
    int N, M, T;
    scanf("%d %d", &N, &M);
    char terrain[MAX_ROWS][MAX_COLS];

    for (int i = 0; i < N; i++) {
        scanf("%s", terrain[i]);
    }

    scanf("%d", &T);
    int towers[MAX_TOWERS];
    for (int i = 0; i < T; i++) {
        scanf("%d", &towers[i]);
    }

    int visible_areas = 0;
    char visible_terrain[MAX_ROWS][MAX_COLS];

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            visible_terrain[i][j] = terrain[i][j];
        }
    }

    count_visible_areas(N, M, terrain, T, towers, &visible_areas, visible_terrain);

    printf("%d\n", visible_areas);
    for (int i = 0; i < N; i++) {
        printf("%s\n", visible_terrain[i]);
    }

    return 0;
}
