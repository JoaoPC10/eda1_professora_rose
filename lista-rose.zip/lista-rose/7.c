#include <stdio.h>
#include <stdlib.h>

typedef struct celula {
  int dado;
  struct celula *prox;
} celula;

// Função para enfileirar um elemento na fila
void enfileira(celula **f, int x) {
  celula *novo = (celula *)malloc(sizeof(celula));
  if (novo) {
    novo->dado = x;
    novo->prox = NULL;

    if (*f == NULL) {
      *f = novo;
    } else {
      celula *atual = *f;
      while (atual->prox != NULL) {
        atual = atual->prox;
      }
      atual->prox = novo;
    }
  }
}

// Função para desenfileirar um elemento da fila
int desenfileira(celula **f, int *y) {
  if (*f == NULL) return 0;

  celula *removido = *f;
  *y = removido->dado;
  *f = removido->prox;
  free(removido);

  return 1;
}

// Função principal
/*int main() { 
  int n;
  printf("Digite o valor de n: ");
  scanf("%d", &n);
  
  celula *fila = NULL;

  // Enfileirando os números de 1 a n
  for (int i = 1; i <= n; i++) {
    enfileira(&fila, i);
  }

  // Desenfileirando e imprimindo as cartas descartadas
  printf("Cartas descartadas: ");
  while (fila != NULL && fila->prox != NULL) {
    int descartada;
    desenfileira(&fila, &descartada);
    printf("%d, ", descartada);
    int movida;
    desenfileira(&fila, &movida);
    enfileira(&fila, movida);
  }
  printf("\n");

  // Imprimindo a carta restante
  if (fila != NULL) {
    printf("Carta restante: %d\n", fila->dado);
  }

  // Liberando a memória da fila
  celula *atual = fila;
  while (atual != NULL) {
    celula *prox = atual->prox;
    free(atual);
    atual = prox;
  }

  return 0;
}*/