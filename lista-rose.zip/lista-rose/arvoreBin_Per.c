#include <stdio.h>
#include <stdlib.h>

// Estrutura do nó da árvore
typedef struct Node {
    int data;
    struct Node *left, *right;
} Node;

// Função para criar um novo nó
Node* createNode(int data) {
    Node *newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

// Função para inserir um novo nó na árvore binária de busca
Node* insertNode(Node *root, int data) {
    if (root == NULL) {
        return createNode(data);
    }

    if (data < root->data) {
        root->left = insertNode(root->left, data);
    } else {
        root->right = insertNode(root->right, data);
    }

    return root;
}

// Função para travessia em pré-ordem
void preOrder(Node *root) {
    if (root != NULL) {
        printf("%d ", root->data);
        preOrder(root->left);
        preOrder(root->right);
    }
}

// Função para travessia em ordem
void inOrder(Node *root) {
    if (root != NULL) {
        inOrder(root->left);
        printf("%d ", root->data);
        inOrder(root->right);
    }
}

// Função para travessia em pós-ordem
void postOrder(Node *root) {
    if (root != NULL) {
        postOrder(root->left);
        postOrder(root->right);
        printf("%d ", root->data);
    }
}

// Função principal
int main() {
    Node *root = NULL;
    int value;

    // Ler números da entrada padrão até EOF
    while (scanf("%d", &value) != EOF) {
        root = insertNode(root, value);
    }

    // Imprimir as travessias da árvore
    preOrder(root);
    printf(".\n");
    inOrder(root);
    printf(".\n");
    postOrder(root);
    printf(".\n");

    return 0;
}
