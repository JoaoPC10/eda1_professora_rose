#include <stdio.h>

int main() {
    int n, m, v = 0;
    scanf("%d %d", &n, &m);

    char grid[n][m+1];
    for (int i = 0; i < n; ++i)
        scanf("%s", grid[i]);

    for (int i = 0; i < n; ++i) {
        for (int j = 0, h; j < m; ++j) {
            if (grid[i][j] != 't') continue;
            scanf("%d", &h);

            int lx = j-h, ly = i-h, hx = j+h, hy = i+h;
            lx = lx > 0 ? lx : 0;
            ly = ly > 0 ? ly : 0;
            hx = hx >= m ? m-1 : hx;
            hy = hy >= n ? n-1 : hy;
            for (int k = ly; k <= hy; ++k)
                for (int l = lx; l <= hx; ++l)
                    if (grid[k][l] == '#') {
                        grid[k][l] = '.';
                        ++v;
                    }
        }
    }

    printf("%d\n", v);
    for (int i = 0; i < n; ++i)
        printf("%s\n", grid[i]);
}