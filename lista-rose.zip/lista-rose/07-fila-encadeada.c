#include <stdio.h>
#include <stdlib.h>

typedef struct celula {
  int dado;
  struct celula *prox;
} celula;

void enfileira (celula **f, int x) {
  celula *novo = malloc(sizeof(celula));
  if(novo) {
    novo->prox = (*f)->prox;
    (*f)->prox = novo;
    (*f)->dado = x;
  }
  return NULL;
}

int desenfileira (celula *f, int *y) {
  if(f->prox == NULL) return 0;

  *y = f->prox->dado;
  *f->prox = *f->prox->prox;

  return 1;
}
/*
int main() { 
    celula *cabeca = malloc(sizeof(celula));
    celula **cabeca2 = &cabeca;
    celula *um = malloc(sizeof(celula));
    celula *dois = malloc(sizeof(celula));
    um->dado = 1;
    um->prox= dois;
    
    dois->dado = 2;
    dois->prox= NULL;
    cabeca->prox = um;
    
    enfileira(cabeca2, 3);
      
    for(celula *p = cabeca; p != NULL;) {
        printf("%d\n", p->dado);
        p = p->prox;
    }
  
    int y;

    desenfileira(cabeca, &y);

    for(celula *p = cabeca; p != NULL;) {
        printf("%d\n", p->dado);
        p = p->prox;
    }
    //printf("%d\n", cabeca->prox->dado);
    //printf("%d\n", cabeca->prox->prox->dado);
    
    
    // printf("%d\n", inserido->dado);
    // celula *item = cabeca->prox;
    // while(item->prox != NULL) {
    //     printf("Dado: %d\n", item->dado);
    //     item = item->prox;
    // }

    return 0;
}*/
