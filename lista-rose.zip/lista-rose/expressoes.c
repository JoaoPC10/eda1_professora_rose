#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SIZE 100000

// Função para verificar se um caractere é um caractere de abertura
int isOpening(char c) {
    return c == '(' || c == '[' || c == '{';
}

// Função para verificar se um caractere é um caractere de fechamento
int isClosing(char c) {
    return c == ')' || c == ']' || c == '}';
}

// Função para verificar se os caracteres de abertura e fechamento formam um par válido
int isMatchingPair(char opening, char closing) {
    return (opening == '(' && closing == ')') ||
           (opening == '[' && closing == ']') ||
           (opening == '{' && closing == '}');
}

// Função para verificar se uma cadeia é bem definida
int isWellDefined(char *expression) {
    char stack[MAX_SIZE];
    int top = -1; // Inicializa o topo da pilha

    int length = strlen(expression);
    for (int i = 0; i < length; i++) {
        char current = expression[i];
        
        if (isOpening(current)) {
            stack[++top] = current; // Empilha caracteres de abertura
        } else if (isClosing(current)) {
            if (top == -1 || !isMatchingPair(stack[top], current)) {
                return 0; // Não é bem definida se a pilha estiver vazia ou se os pares não corresponderem
            }
            top--; // Desempilha caracteres de fechamento correspondentes
        }
    }
    
    return top == -1; // A pilha deve estar vazia se a expressão for bem definida
}

int main() {
    int T;
    scanf("%d", &T);
    
    char expression[MAX_SIZE + 1]; // Buffer para armazenar cada expressão
    
    for (int i = 0; i < T; i++) {
        scanf("%s", expression);
        if (isWellDefined(expression)) {
            printf("S\n");
        } else {
            printf("N\n");
        }
    }
    
    return 0;
}
