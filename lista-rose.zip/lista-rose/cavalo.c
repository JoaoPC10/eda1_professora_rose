#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BOARD_SIZE 8

// Estrutura para representar uma posição no tabuleiro
typedef struct {
    int x, y;
    int dist; // Distância (número de movimentos) da origem
} Position;

// Movimentos possíveis do cavalo
int moves[8][2] = {
    {2, 1}, {1, 2}, {-1, 2}, {-2, 1},
    {-2, -1}, {-1, -2}, {1, -2}, {2, -1}
};

// Verifica se a posição está dentro dos limites do tabuleiro
int isValid(int x, int y) {
    return (x >= 0 && x < BOARD_SIZE && y >= 0 && y < BOARD_SIZE);
}

// Converte a notação do xadrez (ex: 'a1') para coordenadas (x, y)
Position convertToPosition(char *notation) {
    Position pos;
    pos.x = notation[0] - 'a';
    pos.y = notation[1] - '1';
    pos.dist = 0; // Inicialmente, a distância é 0
    return pos;
}

// Função que usa BFS para encontrar o menor número de movimentos do cavalo
int findMinMoves(Position start, Position end) {
    // Verifica se o início e o fim são a mesma posição
    if (start.x == end.x && start.y == end.y) {
        return 0;
    }

    // Fila para BFS
    Position queue[BOARD_SIZE * BOARD_SIZE];
    int front = 0, rear = 0;

    // Marcar todas as posições como não visitadas
    int visited[BOARD_SIZE][BOARD_SIZE];
    memset(visited, 0, sizeof(visited));

    // Adicionar posição inicial à fila e marcar como visitada
    queue[rear++] = start;
    visited[start.x][start.y] = 1;

    while (front < rear) {
        Position current = queue[front++];

        // Explorar todos os movimentos possíveis do cavalo
        for (int i = 0; i < 8; i++) {
            int nx = current.x + moves[i][0];
            int ny = current.y + moves[i][1];

            if (isValid(nx, ny) && !visited[nx][ny]) {
                // Se a posição de destino for encontrada
                if (nx == end.x && ny == end.y) {
                    return current.dist + 1;
                }

                // Adicionar nova posição à fila e marcar como visitada
                queue[rear++] = (Position){nx, ny, current.dist + 1};
                visited[nx][ny] = 1;
            }
        }
    }

    return -1; // Caso não encontrado (não deveria ocorrer)
}

int main() {
    char start[3], end[3];
    
    while (scanf("%s %s", start, end) != EOF) {
        Position startPos = convertToPosition(start);
        Position endPos = convertToPosition(end);
        int moves = findMinMoves(startPos, endPos);
        printf("To get from %s to %s takes %d knight moves.\n", start, end, moves);
    }

    return 0;
}
