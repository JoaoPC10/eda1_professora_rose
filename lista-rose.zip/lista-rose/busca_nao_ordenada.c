#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int value;
    int index;
} Pair;

int compare(const void *a, const void *b) {
    Pair *pairA = (Pair *)a;
    Pair *pairB = (Pair *)b;
    return (pairA->value - pairB->value);
}

int binarySearch(Pair arr[], int l, int r, int x) {
    while (l <= r) {
        int m = l + (r - l) / 2;
        if (arr[m].value == x) {
            return arr[m].index;
        }
        if (arr[m].value < x) {
            l = m + 1;
        } else {
            r = m - 1;
        }
    }
    return -1;
}

int main() {
    int N, M;

    // Lê o valor de N e M
    scanf("%d %d", &N, &M);

    Pair *numeros = (Pair *)malloc(N * sizeof(Pair));
    int numero;

    // Lê os N números do conjunto e armazena suas posições
    for (int i = 0; i < N; i++) {
        scanf("%d", &numero);
        numeros[i].value = numero;
        numeros[i].index = i;
    }

    // Ordena os números para permitir busca binária
    qsort(numeros, N, sizeof(Pair), compare);

    // Lê os M números que devem ser procurados e verifica no conjunto ordenado
    for (int i = 0; i < M; i++) {
        scanf("%d", &numero);
        int result = binarySearch(numeros, 0, N - 1, numero);
        printf("%d\n", result);
    }

    free(numeros);
    return 0;
}
