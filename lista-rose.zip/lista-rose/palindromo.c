#include <stdio.h>
#include <string.h>

int main() {
    int N;
    scanf("%d", &N);
    
    char str[N + 1]; // Adicionamos 1 para o caractere nulo de terminação
    scanf("%s", str);
    
    int is_palindrome = 1; // Assumimos inicialmente que é um palíndromo

    // Comparar caracteres da frente para trás
    for (int i = 0; i < N / 2; ++i) {
        if (str[i] != str[N - i - 1]) {
            is_palindrome = 0; // Se qualquer par de caracteres não coincidir, não é um palíndromo
            break;
        }
    }
    
    printf("%d\n", is_palindrome);

    return 0;
}
