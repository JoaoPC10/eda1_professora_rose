#include <stdio.h>

int buscaBinaria(int v[], int N, int x) {
    int esq = 0;
    int dir = N - 1;
    int meio;

    while (esq <= dir) {
        meio = (esq + dir) / 2;

        if (v[meio] < x) {
            esq = meio + 1;
        } else if (v[meio] >= x) {
            dir = meio - 1;
        }
    }

    return esq;
}

int main() {
    int N, M;
    scanf("%d %d", &N, &M);

    int conjunto[N];
    for (int i = 0; i < N; i++) {
        scanf("%d", &conjunto[i]);
    }

    for (int i = 0; i < M; i++) {
        int x;
        scanf("%d", &x);

        int indice = buscaBinaria(conjunto, N, x);
        printf("%d\n", indice);
    }

    return 0;
}
