#include <stdio.h>
#include <stdlib.h>

#define SWITCH_TO_INSERTION_SORT 10

// Função para trocar dois elementos de posição no array
void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Função de inserção sort para pequenos arrays
void insertion_sort(int arr[], int low, int high) {
    for (int i = low + 1; i <= high; i++) {
        int key = arr[i];
        int j = i - 1;
        while (j >= low && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

// Função para particionar o array para o Quick Sort usando o pivô mediano
int partition(int arr[], int low, int high) {
    int mid = low + (high - low) / 2;

    // Usar a mediana de três como pivô
    if (arr[mid] < arr[low]) {
        swap(&arr[mid], &arr[low]);
    }
    if (arr[high] < arr[low]) {
        swap(&arr[high], &arr[low]);
    }
    if (arr[high] < arr[mid]) {
        swap(&arr[high], &arr[mid]);
    }

    int pivot = arr[mid];
    swap(&arr[mid], &arr[high]);

    int i = low - 1;
    for (int j = low; j <= high - 1; j++) {
        if (arr[j] <= pivot) {
            i++;
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return (i + 1);
}

// Função principal do Quick Sort com limite para inserção sort
void quick_sort(int arr[], int low, int high) {
    while (low < high) {
        if (high - low < SWITCH_TO_INSERTION_SORT) {
            insertion_sort(arr, low, high);
            break;
        } else {
            int pi = partition(arr, low, high);

            // Ordenar primeiro a menor das duas partições
            if (pi - low < high - pi) {
                quick_sort(arr, low, pi - 1);
                low = pi + 1;
            } else {
                quick_sort(arr, pi + 1, high);
                high = pi - 1;
            }
        }
    }
}

int main() {
    int n;

    // Ler a quantidade de elementos
    scanf("%d", &n);

    // Alocar espaço para os elementos
    int *numbers = (int *)malloc(n * sizeof(int));

    // Ler os elementos
    for (int i = 0; i < n; i++) {
        scanf("%d", &numbers[i]);
    }

    // Ordenar o array usando Quick Sort
    quick_sort(numbers, 0, n - 1);

    // Imprimir o array ordenado
    for (int i = 0; i < n; i++) {
        if (i > 0) {
            printf(" ");
        }
        printf("%d", numbers[i]);
    }
    printf("\n");

    // Liberar a memória alocada
    free(numbers);

    return 0;
}
