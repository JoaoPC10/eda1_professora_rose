#include <stdio.h>

#define ll long long

ll upper_bound(ll* xs, ll x, ll l, ll r) {
    if (l > r) return l;

    ll m = (l + r) / 2;
    if (xs[m] == x) return m;

    l = (xs[m] < x ? m + 1 : l);
    r = (xs[m] > x ? m - 1 : r);
    return upper_bound(xs, x, l, r);
}

int main() {
    ll c, t;
    scanf("%lld %lld", &c, &t);

    ll raios_sqr[c];
    for (int i = 0; i < c; ++i) {
        scanf("%lld", &raios_sqr[i]);
        raios_sqr[i] *= raios_sqr[i];
    }

    ll pontos = 0;
    while (t--) {
        ll x, y;
        scanf("%lld %lld", &x, &y);

        pontos += c-upper_bound(raios_sqr, x*x + y*y, 0, c-1);
    }

    printf("%lld\n", pontos);
}