#include <stdio.h>

typedef struct celula {
    int dado;
    struct celula *prox;
} celula;

void remove_elemento ( celula *le, int x)
{
   celula *p, *q;
   p = le;
   q = le->prox;
   while (q != NULL && q->dado != x) {
      p = q;
      q = q->prox;
   }
   if (q != NULL) {
      p->prox = q->prox;
      free (q);
   }
}