#include <stdio.h>
#include <stdlib.h>

// Definição da estrutura do nó da lista encadeada
typedef struct Node {
    int col;
    int value;
    struct Node *next;
} Node;

// Função para criar um novo nó
Node* createNode(int col, int value) {
    Node *newNode = (Node*)malloc(sizeof(Node));
    if (newNode == NULL) {
        fprintf(stderr, "Erro ao alocar memória.\n");
        exit(EXIT_FAILURE);
    }
    newNode->col = col;
    newNode->value = value;
    newNode->next = NULL;
    return newNode;
}

// Função para inserir um nó na lista encadeada
void insert(Node **head, int col, int value) {
    Node *newNode = createNode(col, value);
    newNode->next = *head;
    *head = newNode;
}

int main() {
    int m, n;
    scanf("%d %d", &m, &n);

    // Vetor para armazenar o resultado do produto
    int *result = (int*)malloc(m * sizeof(int));
    if (result == NULL) {
        fprintf(stderr, "Erro ao alocar memória.\n");
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < m; i++) {
        result[i] = 0;
    }

    // Vetor de cabeças das listas encadeadas
    Node **heads = (Node**)malloc(m * sizeof(Node*));
    if (heads == NULL) {
        fprintf(stderr, "Erro ao alocar memória.\n");
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < m; i++) {
        heads[i] = NULL;
    }

    // Lê os elementos não nulos da matriz e armazena na lista encadeada
    int row, col, value;
    while (scanf("%d %d %d", &row, &col, &value) == 3 && row != -1) {
        insert(&heads[row], col, value);
    }

    // Lê o vetor
    int *vector = (int*)malloc(n * sizeof(int));
    if (vector == NULL) {
        fprintf(stderr, "Erro ao alocar memória.\n");
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < n; i++) {
        scanf("%d", &vector[i]);
    }

    // Calcula o produto matriz-vetor
    for (int i = 0; i < m; i++) {
        Node *current = heads[i];
        while (current != NULL) {
            result[i] += current->value * vector[current->col];
            current = current->next;
        }
    }

    // Imprime o vetor resultante
    for (int i = 0; i < m; i++) {
        printf("%d\n", result[i]);
    }

    // Libera a memória alocada
    for (int i = 0; i < m; i++) {
        Node *current = heads[i];
        while (current != NULL) {
            Node *temp = current;
            current = current->next;
            free(temp);
        }
    }
    free(heads);
    free(result);
    free(vector);

    return 0;
}
