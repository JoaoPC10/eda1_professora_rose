#include <stdio.h>
#include <stdlib.h>

// Função para verificar se os caminhões podem ser reorganizados
char* canReorder(int n, int trucks[]) {
    int stack[1000];
    int top = -1;
    int expected = 1;

    for (int i = 0; i < n; i++) {
        while (top != -1 && stack[top] == expected) {
            top--;
            expected++;
        }
        if (trucks[i] == expected) {
            expected++;
        } else {
            stack[++top] = trucks[i];
        }
    }

    while (top != -1 && stack[top] == expected) {
        top--;
        expected++;
    }

    return (top == -1) ? "yes" : "no";
}

int main() {
    int n;
    while (1) {
        scanf("%d", &n);
        if (n == 0) {
            break;
        }
        int trucks[n];
        for (int i = 0; i < n; i++) {
            scanf("%d", &trucks[i]);
        }
        printf("%s\n", canReorder(n, trucks));
    }
    return 0;
}
