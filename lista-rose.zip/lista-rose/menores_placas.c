#include <stdio.h>
#include <stdlib.h>

#define MAX_HEAP_SIZE 45000

void trocar(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

void minHeapify(int heap[], int tamanho_heap, int indice) {
    int menor = indice;
    int filho_esq = 2 * indice + 1;
    int filho_dir = 2 * indice + 2;

    if (filho_esq < tamanho_heap && heap[filho_esq] < heap[menor]) {
        menor = filho_esq;
    }

    if (filho_dir < tamanho_heap && heap[filho_dir] < heap[menor]) {
        menor = filho_dir;
    }

    if (menor != indice) {
        trocar(&heap[indice], &heap[menor]);
        minHeapify(heap, tamanho_heap, menor);
    }
}

void inserirHeap(int heap[], int *tamanho_heap, int valor) {
    heap[*tamanho_heap] = valor;
    (*tamanho_heap)++;
    int i = *tamanho_heap - 1;

    while (i > 0 && heap[(i - 1) / 2] > heap[i]) {
        trocar(&heap[i], &heap[(i - 1) / 2]);
        i = (i - 1) / 2;
    }
}

int extrairMinHeap(int heap[], int *tamanho_heap) {
    if (*tamanho_heap <= 0) {
        return -1;
    }

    int menor = heap[0];
    heap[0] = heap[*tamanho_heap - 1];
    (*tamanho_heap)--;
    minHeapify(heap, *tamanho_heap, 0);

    return menor;
}

int main() {
    int O, valor;
    int heap[MAX_HEAP_SIZE];
    int tamanho_heap = 0;

    while (scanf("%d", &O) != EOF) {
        if (O == 1) {
            scanf("%d", &valor);
            inserirHeap(heap, &tamanho_heap, valor);
        } else if (O == 2) {
            int Ti;
            scanf("%d", &Ti);
            int menores[Ti];

            for (int i = 0; i < Ti; ++i) {
                menores[i] = extrairMinHeap(heap, &tamanho_heap);
                if (menores[i] == -1) {
                    break;
                }
            }

            for (int i = 0; i < Ti && menores[i] != -1; ++i) {
                printf("%d%c", menores[i], (i < Ti - 1 && menores[i + 1] != -1) ? ' ' : '\n');
            }

            for (int i = 0; i < Ti && menores[i] != -1; ++i) {
                inserirHeap(heap, &tamanho_heap, menores[i]);
            }
        }
    }

    return 0;
}
