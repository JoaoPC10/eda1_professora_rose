#include <stdio.h>

int main() {
    int P, R, test_case = 1;

    while (1) {
        // Ler P e R
        scanf("%d %d", &P, &R);
        
        // Terminar se P e R forem ambos 0
        if (P == 0 && R == 0) {
            break;
        }

        // Ler a fila inicial
        int fila[P];
        for (int i = 0; i < P; i++) {
            scanf("%d", &fila[i]);
        }

        // Processar cada rodada
        for (int r = 0; r < R; r++) {
            int N, J;
            scanf("%d %d", &N, &J);
            
            // Ler as ações dos participantes na rodada
            int acao[N];
            for (int i = 0; i < N; i++) {
                scanf("%d", &acao[i]);
            }

            // Eliminar os participantes que não seguem a ordem do chefe
            int nova_fila[P], nova_tamanho = 0;
            for (int i = 0; i < N; i++) {
                if (acao[i] == J) {
                    nova_fila[nova_tamanho++] = fila[i];
                }
            }

            // Atualizar a fila para a próxima rodada
            for (int i = 0; i < nova_tamanho; i++) {
                fila[i] = nova_fila[i];
            }
            P = nova_tamanho;
        }

        // Imprimir o resultado do teste
        printf("Teste %d\n", test_case++);
        printf("%d\n\n", fila[0]);
    }

    return 0;
}
