#include <stdio.h>
#include <stdlib.h>

// Função para realizar o Insertion Sort
void insertion_sort(int arr[], int n) {
    int i, key, j;
    for (i = 1; i < n; i++) {
        key = arr[i];
        j = i - 1;

        // Move os elementos de arr[0..i-1] que são maiores que key
        // para uma posição à frente de sua posição atual
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}

int main() {
    int numbers[50000];
    int n = 0;

    // Ler a entrada até EOF
    while (scanf("%d", &numbers[n]) != EOF) {
        n++;
    }

    // Ordenar o array usando Insertion Sort
    insertion_sort(numbers, n);

    // Imprimir o array ordenado
    for (int i = 0; i < n; i++) {
        if (i > 0) {
            printf(" ");
        }
        printf("%d", numbers[i]);
    }
    printf("\n");

    return 0;
}
