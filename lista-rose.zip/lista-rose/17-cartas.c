#include <stdio.h>
#include <stdlib.h>

#define MAX 1000000

typedef struct stack {
  int *dados;
  int N, topo;
} stack;

int empilha(stack *s, int x) {
  s->dados[s->topo++] = x;
  return 1;
}

int desempilha(stack *s, int *y) {
  if(s->topo == 0) return 0;
  *y = s->dados[s->topo--];
  return 1;
}

int main () {
  int N;
  scanf("%d", &N);
  int *dados = (int *)malloc(MAX * sizeof(int)); 
  stack *s = malloc(sizeof(stack));
  s->N=N;
  s->dados = dados;
  s->topo = 0;
  printf("%d", s->N);

  for (int i = N; i > 0; i--) {
    // dados[i] = i;
    empilha(s, i);
  }

  for(int i = 0; i < N; i++) {
    printf("%d ", s->dados[i]);
  }
  printf("\n");



  
  return 0;
}



