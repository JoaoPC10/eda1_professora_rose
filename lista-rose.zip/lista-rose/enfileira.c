#include <stdio.h>

typedef struct fila{
    int *dados;
    int N,p,u;
}fila;

int desenfileira (fila *f, int *x){
   if(f->p == f->u) return 0;
   f->dados[f->u++] = x;
   if (f->u == f->N) f->u = 0;
   return 1;
}//nao feito