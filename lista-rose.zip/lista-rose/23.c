#include <stdio.h>
#include <stdlib.h>

typedef struct celula {
    int dado;
    struct celula* prox;
} celula;

int desempilha(celula* p, int* y) {
    if (p->prox == 0) return 0;
    celula* n = p->prox;
    *y = n->dado;
    p->prox = n->prox;
    free(n);
    return 1;
}

void empilha(celula* p, int x) {
    celula* novo = malloc(sizeof(celula));
    novo->dado = x;
    novo->prox = p->prox;
    p->prox = novo;
}

int main() {
    int n;
    scanf("%d", &n);

    celula stack = {};

    while (n--) {
        char line[100001];
        scanf(" %[^\n]", line);

        int i = -1, ignore;
        while (line[++i])
            if (line[i] == '*' || line[i] == '/' || line[i] == '_') {
                if (stack.prox && stack.prox->dado == line[i])
                    desempilha(&stack, &ignore);
                else
                    empilha(&stack, line[i]);
            }
    }

    if (stack.prox == NULL)
        printf("C\n");
    else
        printf("E\n");
}