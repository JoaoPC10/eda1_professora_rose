#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LENGTH 100

// Definição da estrutura da pilha
typedef struct stackNode {
    char change[MAX_LENGTH + 1];
    struct stackNode *next;
} stackNode;

// Função para criar um novo nó da pilha
stackNode* createNode(const char *change) {
    stackNode *newNode = (stackNode*)malloc(sizeof(stackNode));
    if (newNode == NULL) {
        fprintf(stderr, "Erro ao alocar memória.\n");
        exit(EXIT_FAILURE);
    }
    strcpy(newNode->change, change);
    newNode->next = NULL;
    return newNode;
}

// Função para empilhar uma alteração
void push(stackNode **top, const char *change) {
    stackNode *newNode = createNode(change);
    newNode->next = *top;
    *top = newNode;
}

// Função para desempilhar uma alteração
char* pop(stackNode **top) {
    if (*top == NULL) {
        return NULL;
    }
    stackNode *temp = *top;
    *top = (*top)->next;
    char *poppedChange = strdup(temp->change); // Copia a string de alteração
    free(temp); // Libera a memória alocada para o nó da pilha
    return poppedChange;
}

int main() {
    stackNode *stack = NULL;
    char command[MAX_LENGTH + 10];  // Buffer para ler os comandos
    char change[MAX_LENGTH + 1];    // Buffer para ler a alteração

    while (scanf("%s", command) != EOF) {
        if (strcmp(command, "desfazer") == 0) {
            char *poppedChange = pop(&stack);
            if (poppedChange != NULL) {
                printf("%s\n", poppedChange);
                free(poppedChange); // Libera a memória alocada para a string
            } else {
                printf("NULL\n");
            }
        } else if (strcmp(command, "inserir") == 0) {
            // Lê a string da alteração
            scanf(" %[^\n]", change);  // Lê até o final da linha
            push(&stack, change);
        }
    }

    // Limpa a pilha (se houver alguma alteração restante)
    while (stack != NULL) {
        char *poppedChange = pop(&stack);
        free(poppedChange);
    }

    return 0;
}
