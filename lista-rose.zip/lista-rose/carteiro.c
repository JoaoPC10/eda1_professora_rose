#include <stdio.h>
#include <stdlib.h>

// Função para comparar dois inteiros (necessária para qsort)
int compare(const void *a, const void *b) {
    return (*(int *)a - *(int *)b);
}

// Função para buscar o índice de um elemento em um array ordenado usando busca binária
int buscaBinaria(int chave, int array[], int tamanho) {
    int inicio = 0, fim = tamanho - 1;
    while (inicio <= fim) {
        int meio = inicio + (fim - inicio) / 2;
        if (array[meio] == chave)
            return meio;
        else if (array[meio] < chave)
            inicio = meio + 1;
        else
            fim = meio - 1;
    }
    return -1; // Elemento não encontrado
}

int main() {
    int N, M;
    int casas[45000];
    int encomendas[45000];
    
    // Leitura da entrada
    while (scanf("%d %d\n", &N, &M) == 2) {
        // Lendo as casas
        for (int i = 0; i < N; ++i) {
            scanf("%d", &casas[i]);
        }
        
        // Ordenando as casas
        qsort(casas, N, sizeof(int), compare);
        
        // Lendo as encomendas e calculando tempo total de entrega
        int casa_atual = casas[0];
        long long tempo_total = 0; // Usar long long para evitar estouro de int
        
        for (int i = 0; i < M; ++i) {
            scanf("%d", &encomendas[i]);
            
            // Busca binária para encontrar a posição da encomenda atual
            int pos_encomenda = buscaBinaria(encomendas[i], casas, N);
            
            // Calcular tempo de entrega até a encomenda atual
            tempo_total += abs(pos_encomenda - buscaBinaria(casa_atual, casas, N));
            
            // Atualizar a casa atual
            casa_atual = encomendas[i];
        }
        
        // Imprimir o tempo total de entrega
        printf("%lld\n", tempo_total);
    }
    
    return 0;
}
