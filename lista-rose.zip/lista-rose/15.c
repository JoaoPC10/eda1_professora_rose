#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int *v;     // Vetor que contém os elementos da pilha
    int N;      // Tamanho de v
    int topo;   // Indicador do topo
} pilha;

void empilha(pilha *p, int x) {
    // Verifica se a pilha está cheia
    if (p->topo == p->N) {
        // Dobra o tamanho do vetor
        p->N *= 2;
        p->v = realloc(p->v, p->N * sizeof(int));
        if (p->v == NULL) {
            fprintf(stderr, "Erro: Falha na alocação de memória.\n");
            exit(EXIT_FAILURE);
        }
    }
    // Empilha o elemento x
    p->v[p->topo++] = x;
}

int desempilha(pilha *p, int *y) {
    // Verifica se a pilha está vazia
    if (p->topo == 0) {
        return 0; // Desempilhamento mal sucedido (pilha vazia)
    }
    // Desempilha o elemento
    *y = p->v[--p->topo];
    return 1; // Desempilhamento bem sucedido
}
