#include <stdio.h>
#include <stdlib.h>

// Função para realizar o Bubble Sort
void bubble_sort(int arr[], int n) {
    int i, j, temp;
    for (i = 0; i < n-1; i++) {
        // Flag to check if any swapping happened
        int swapped = 0;
        for (j = 0; j < n-i-1; j++) {
            if (arr[j] > arr[j+1]) {
                // Swap the elements
                temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
                swapped = 1;
            }
        }
        // If no swapping happened, the array is already sorted
        if (!swapped) {
            break;
        }
    }
}

int main() {
    int numbers[1000];
    int n = 0;

    // Read input until EOF
    while (scanf("%d", &numbers[n]) != EOF) {
        n++;
    }

    // Sort the array using Bubble Sort
    bubble_sort(numbers, n);

    // Print the sorted array
    for (int i = 0; i < n; i++) {
        if (i > 0) {
            printf(" ");
        }
        printf("%d", numbers[i]);
    }
    printf("\n");

    return 0;
}
