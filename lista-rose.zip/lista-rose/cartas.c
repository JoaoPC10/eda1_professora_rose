#include <stdio.h>

void descartar_cartas(int n) {
    int cartas[n];
    int descartadas[n];
    int topo = 0; // Índice do topo da pilha
    int base = n; // Índice da base da pilha

    // Preenchendo a pilha com as cartas de 1 a n
    for (int i = 0; i < n; i++) {
        cartas[i] = i + 1;
    }

    // Inicializando o índice das cartas descartadas
    int index_descartadas = 0;

    // Enquanto houver duas ou mais cartas na pilha
    while (base - topo >= 2) {
        // Descarta a carta do topo
        descartadas[index_descartadas++] = cartas[topo++];
        // Move a próxima carta para a base da pilha
        cartas[base++] = cartas[topo++];
    }

    // Imprimindo as cartas descartadas
    printf("Cartas descartadas: ");
    for (int i = 0; i < index_descartadas; i++) {
        printf("%d", descartadas[i]);
        if (i < index_descartadas - 1) {
            printf(", ");
        }
    }
    printf("\n");

    // Imprimindo a última carta na pilha
    printf("Carta restante: %d\n", cartas[topo]);
}

int main() {
    int n;
    scanf("%d", &n);

    descartar_cartas(n);

    return 0;
}
