#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Estrutura para armazenar as instruções
typedef struct {
    int code;
    char keyword[16];
} Instruction;

// Função de comparação para qsort
int compare_instructions(const void *a, const void *b) {
    Instruction *instrA = (Instruction *)a;
    Instruction *instrB = (Instruction *)b;
    return (instrA->code - instrB->code);
}

// Função de comparação para bsearch
int compare_code(const void *a, const void *b) {
    int *codeA = (int *)a;
    Instruction *instrB = (Instruction *)b;
    return (*codeA - instrB->code);
}

int main() {
    int n;

    // Ler o número de instruções
    if (scanf("%d", &n) != 1) return 1;

    // Alocar memória para as instruções
    Instruction *instructions = (Instruction *)malloc(n * sizeof(Instruction));
    if (instructions == NULL) return 1;

    // Ler as instruções
    for (int i = 0; i < n; i++) {
        if (scanf("%d %15s", &instructions[i].code, instructions[i].keyword) != 2) {
            free(instructions);
            return 1;
        }
    }

    // Ordenar as instruções por código
    qsort(instructions, n, sizeof(Instruction), compare_instructions);

    int code;
    // Ler os códigos de instruções a serem consultados até EOF
    while (scanf("%d", &code) == 1) {
        // Realizar a busca binária
        Instruction *result = (Instruction *)bsearch(&code, instructions, n, sizeof(Instruction), compare_code);
        if (result != NULL) {
            printf("%s\n", result->keyword);
        } else {
            printf("undefined\n");
        }
    }

    // Liberar a memória alocada
    free(instructions);

    return 0;
}
