#include <stdio.h>
#include <stdlib.h>

#define MAX_ELEMENTS 131072
#define NMU_INSERTION_VALUE 1000000000

// Função de comparação para qsort
int compare(const void *a, const void *b) {
    return (*(int *)a - *(int *)b);
}

// Função para remover duplicatas de um array ordenado
int remove_duplicates(int *arr, int size) {
    if (size == 0 || size == 1)
        return size;
    int j = 0;
    for (int i = 0; i < size - 1; i++)
        if (arr[i] != arr[i + 1])
            arr[j++] = arr[i];
    arr[j++] = arr[size - 1];
    return j;
}

// Função para inserir um número no array mantendo-o ordenado e sem duplicatas
int insert_unique_sorted(int *arr, int size, int num) {
    int i;
    for (i = size - 1; (i >= 0 && arr[i] > num); i--)
        arr[i + 1] = arr[i];
    arr[i + 1] = num;
    return size + 1;
}

int main() {
    int n;
    scanf("%d", &n);

    int arr[MAX_ELEMENTS];
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    // Ordenar o array e remover duplicatas
    qsort(arr, n, sizeof(int), compare);
    n = remove_duplicates(arr, n);

    // Adicionar 1 bilhão se o número de elementos for ímpar
    if (n % 2 != 0) {
        arr[n++] = NMU_INSERTION_VALUE;
    }

    // Gerar os Números Malucos (NMU)
    int nmu[MAX_ELEMENTS];
    int nmu_count = 0;
    for (int i = 0; i < n; i += 2) {
        int sum = arr[i] + arr[i + 1];
        int found = 0;
        for (int j = 0; j < n; j++) {
            if (arr[j] == sum) {
                found = 1;
                break;
            }
        }
        if (!found) {
            nmu[nmu_count++] = sum;
        }
    }

    // Reinserir os Números Malucos no array original
    for (int i = 0; i < nmu_count; i++) {
        n = insert_unique_sorted(arr, n, nmu[i]);
    }

    // Imprimir os elementos de 4 em 4 índices
    for (int i = 0; i < n; i += 4) {
        printf("%d\n", arr[i]);
    }

    // Imprimir a quantidade de elementos únicos
    printf("Elementos: %d\n", n);

    return 0;
}
