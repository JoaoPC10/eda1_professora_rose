#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Estrutura para nós da tabela hash
typedef struct Node {
    int key;
    struct Node* next;
} Node;

// Estrutura da tabela hash
typedef struct {
    Node** table;
    int size;
} HashTable;

// Função para criar uma nova tabela hash
HashTable* createHashTable(int size) {
    HashTable* hashTable = (HashTable*)malloc(sizeof(HashTable));
    hashTable->size = size;
    hashTable->table = (Node**)malloc(size * sizeof(Node*));
    for (int i = 0; i < size; i++) {
        hashTable->table[i] = NULL;
    }
    return hashTable;
}

// Função de hash
int hashFunction(int key, int size) {
    return key % size;
}

// Função para inserir um valor na tabela hash
void insert(HashTable* hashTable, int key) {
    int index = hashFunction(key, hashTable->size);
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->key = key;
    newNode->next = hashTable->table[index];
    hashTable->table[index] = newNode;
}

// Função para verificar se um valor está na tabela hash
int search(HashTable* hashTable, int key) {
    int index = hashFunction(key, hashTable->size);
    Node* current = hashTable->table[index];
    while (current != NULL) {
        if (current->key == key) {
            return 1; // Encontrado
        }
        current = current->next;
    }
    return 0; // Não encontrado
}

// Função para liberar a memória da tabela hash
void freeHashTable(HashTable* hashTable) {
    for (int i = 0; i < hashTable->size; i++) {
        Node* current = hashTable->table[i];
        while (current != NULL) {
            Node* temp = current;
            current = current->next;
            free(temp);
        }
    }
    free(hashTable->table);
    free(hashTable);
}

int main() {
    int N;
    
    // Leitura da quantidade de números proibidos
    scanf("%d", &N);
    
    HashTable* hashTable = createHashTable(N);
    
    // Leitura dos números proibidos e inserção na tabela hash
    for (int i = 0; i < N; i++) {
        int num;
        scanf("%d", &num);
        insert(hashTable, num);
    }
    
    int query;
    
    // Leitura e verificação das consultas até EOF
    while (scanf("%d", &query) != EOF) {
        if (search(hashTable, query)) {
            printf("sim\n");
        } else {
            printf("nao\n");
        }
    }
    
    freeHashTable(hashTable);
    return 0;
}
