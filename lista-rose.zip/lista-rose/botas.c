#include <stdio.h>

int main() {
    int boots[61][2] = {0}; // Inicializa o mapa de botas
    int size, pairs = 0;
    char side;

    // Lê as botas e atualiza o mapa
    while (scanf("%d %c", &size, &side) != EOF) {
        if (side == 'E') {
            boots[size][0]++;
        } else {
            boots[size][1]++;
        }
    }

    // Conta quantos pares completos de botas temos
    for (int i = 30; i <= 60; i++) {
        pairs += (boots[i][0] < boots[i][1]) ? boots[i][0] : boots[i][1];
    }

    printf("%d\n", pairs);
    return 0;
}
