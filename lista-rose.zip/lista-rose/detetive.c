#include <stdio.h>
#include <stdlib.h>

// Estrutura para representar uma pista
typedef struct Pista {
    int identificador;
    int valor;
    int proximo;
} Pista;

int main() {
    int n;
    scanf("%d", &n); // Lê o número de pistas

    Pista *pistas = (Pista *)malloc(n * sizeof(Pista)); // Aloca memória para as pistas

    // Lê as pistas
    for (int i = 0; i < n; i++) {
        scanf("%d %d %d", &pistas[i].identificador, &pistas[i].valor, &pistas[i].proximo);
    }

    // Imprime os valores das pistas na ordem correta
    int atual = pistas[0].identificador; // Começa com o identificador da primeira pista
    while (atual != -1) {
        // Procura a pista atual e imprime seu valor
        for (int i = 0; i < n; i++) {
            if (pistas[i].identificador == atual) {
                printf("%d\n", pistas[i].valor);
                atual = pistas[i].proximo; // Atualiza para o identificador da próxima pista
                break;
            }
        }
    }

    free(pistas); // Libera a memória alocada para as pistas
    return 0;
}
