#include <stdio.h>
#include <math.h>

// Função para realizar busca binária e encontrar quantos círculos contêm o tiro
int pontos_por_tiro(int x, int y, int raios[], int C) {
    long long dist2 = (long long)x * x + (long long)y * y; // Evitar overflow
    int esquerda = 0, direita = C - 1;

    while (esquerda <= direita) {
        int meio = (esquerda + direita) / 2;
        long long raioMeio2 = (long long)raios[meio] * raios[meio];
        if (raioMeio2 < dist2) {
            esquerda = meio + 1;
        } else {
            direita = meio - 1;
        }
    }
    return esquerda;
}

int main() {
    int C, T;
    scanf("%d %d", &C, &T);
    
    int raios[C];
    for (int i = 0; i < C; i++) {
        scanf("%d", &raios[i]);
    }
    
    int total_pontos = 0;
    for (int i = 0; i < T; i++) {
        int x, y;
        scanf("%d %d", &x, &y);
        total_pontos += pontos_por_tiro(x, y, raios, C);
    }
    
    printf("%d\n", total_pontos);
    return 0;
}
