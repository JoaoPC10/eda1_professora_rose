#include <stdio.h>
#include <stdlib.h>

// Definição da estrutura do nó da árvore
typedef struct no {
    int dado;
    struct no *esq, *dir;
} no;

// Definição da estrutura da pilha
typedef struct stackNode {
    no *node;
    struct stackNode *next;
} stackNode;

// Função para criar um novo nó da árvore
no* createNode(int dado) {
    no *newNode = (no*)malloc(sizeof(no));
    if (newNode == NULL) {
        fprintf(stderr, "Erro ao alocar memória.\n");
        exit(EXIT_FAILURE);
    }
    newNode->dado = dado;
    newNode->esq = NULL;
    newNode->dir = NULL;
    return newNode;
}

// Função para empilhar um nó
void push(stackNode **top, no *node) {
    stackNode *newNode = (stackNode*)malloc(sizeof(stackNode));
    if (newNode == NULL) {
        fprintf(stderr, "Erro ao alocar memória.\n");
        exit(EXIT_FAILURE);
    }
    newNode->node = node;
    newNode->next = *top;
    *top = newNode;
}

// Função para desempilhar um nó
no* pop(stackNode **top) {
    if (*top == NULL) {
        return NULL;
    }
    stackNode *temp = *top;
    *top = (*top)->next;
    no *poppedNode = temp->node;
    free(temp);
    return poppedNode;
}

// Função para verificar se a pilha está vazia
int isEmpty(stackNode *top) {
    return top == NULL;
}

// Função para percorrer a árvore em ordem sem recursão
void em_ordem(no *raiz) {
    stackNode *stack = NULL;
    no *current = raiz;

    while (!isEmpty(stack) || current != NULL) {
        // Atravessa a subárvore esquerda
        while (current != NULL) {
            push(&stack, current);
            current = current->esq;
        }

        // Visita o nó no topo da pilha
        current = pop(&stack);
        printf("%d ", current->dado);

        // Atravessa a subárvore direita
        current = current->dir;
    }
}

