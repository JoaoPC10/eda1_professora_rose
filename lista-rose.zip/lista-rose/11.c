#include <stdio.h>
#include <stdlib.h>

typedef struct pilha {
    int *dados;
    int N, topo;
} pilha;

int desempilha(pilha *p, int *y) {
    if (p->topo == 0) {
        return 0; // Pilha vazia, desempilhamento mal sucedido
    }
    *y = p->dados[--(p->topo)];
    return 1; // Desempilhamento bem sucedido
}
