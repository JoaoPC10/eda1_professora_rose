#include <stdlib.h>
#include <stdio.h>

typedef struct fila {
    int *dados;
    int N, p, u;
} fila;



int enfileira(fila *f, int x) {
    
    if (f->u == f->N) {
        
        int novaCapacidade = f->N * 2;
        if (novaCapacidade == 0) {
            novaCapacidade = 1;  
        }

       
        int *novoDados = (int *)realloc(f->dados, novaCapacidade * sizeof(int));
        if (novoDados == NULL) {
            return 0;  
        }

        
        f->dados = novoDados;
        f->N = novaCapacidade;
    }

   
    f->dados[f->u] = x;
    f->u++;
    return 1;  
}
