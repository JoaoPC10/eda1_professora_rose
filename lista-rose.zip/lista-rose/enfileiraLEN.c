#include <stdlib.h>
#include <stdio.h>

// Definição da estrutura celula
typedef struct celula {
    int dado;
    struct celula *prox;
} celula;

// Função para enfileirar um elemento na fila
celula *enfileira(celula *f, int x) {
   celula *nova;
   nova = malloc (sizeof (celula));
   nova->prox = f->prox;
   f->prox = nova;
   f->dado = x;
   return nova;
}