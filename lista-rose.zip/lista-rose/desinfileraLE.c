#include <stdio.h>

typedef struct fila{
    int *dados;
    int N,p,u;
}fila;

int desenfileira (fila *f, int *y){
    if(f->p == f->u) return 0;
    *y = f->dados[f->p];
    f->p++;
    return 1;
}

//-----------------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>

typedef struct fila {
    int *dados;
    int N, p, u;
} fila;

int desenfileira(fila *f, int *y) {
    if (f->p == f->u) // Verifica se a fila está vazia
        return 0;
    
    *y = f->dados[f->p]; // Salva o elemento removido em y
    f->p++; // Incrementa o índice do início da fila
    return 1; // Retorna 1 indicando que a remoção foi bem-sucedida
}
