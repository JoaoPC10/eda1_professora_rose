#include <stdio.h>
#include <stdlib.h>

typedef struct celula {
    int dado;
    struct celula *prox;
} celula;

void empilha(celula *p, int x) {
    celula *nova_celula = (celula*)malloc(sizeof(celula));
    if (nova_celula == NULL) {
        fprintf(stderr, "Erro: Falha na alocação de memória.\n");
        exit(EXIT_FAILURE);
    }
    nova_celula->dado = x;
    nova_celula->prox = p->prox;
    p->prox = nova_celula;
}

int desempilha(celula *p, int *y) {
    if (p->prox == NULL) {
        return 0; // Pilha vazia
    }
    celula *temp = p->prox;
    *y = temp->dado;
    p->prox = temp->prox;
    free(temp);
    return 1;
}
