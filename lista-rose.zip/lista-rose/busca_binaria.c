#include <stdio.h>
#include <stdlib.h>

// Função de busca binária modificada
int buscaBinaria(int arr[], int size, int target) {
    int left = 0, right = size - 1;
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (arr[mid] == target) {
            return mid + 1; // +1 porque queremos 1-based index
        }
        if (arr[mid] < target) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return left; // retorna a posição onde target se encaixaria
}

int main() {
    int N, M;

    // Lê o valor de N e M
    scanf("%d %d", &N, &M);

    int *numeros = (int *)malloc(N * sizeof(int));
    int *procurar = (int *)malloc(M * sizeof(int));

    // Lê os N números do conjunto e armazena no array
    for (int i = 0; i < N; i++) {
        scanf("%d", &numeros[i]);
    }

    // Lê os M números que devem ser procurados
    for (int i = 0; i < M; i++) {
        scanf("%d", &procurar[i]);
    }

    // Procura os M números no conjunto de N números usando busca binária
    for (int i = 0; i < M; i++) {
        int posicao = buscaBinaria(numeros, N, procurar[i]);
        printf("%d\n", posicao);
    }

    // Libera a memória alocada
    free(numeros);
    free(procurar);

    return 0;
}
