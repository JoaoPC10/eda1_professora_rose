#include <stdio.h>
#include <stdlib.h>

// Definição da estrutura do nó da árvore
typedef struct no {
    int dado;
    struct no *esq, *dir;
} no;

// Definição da estrutura da pilha
typedef struct stackNode {
    no *node;
    struct stackNode *next;
} stackNode;

// Função para criar um novo nó da árvore
no* createNode(int dado) {
    no *newNode = (no*)malloc(sizeof(no));
    if (newNode == NULL) {
        fprintf(stderr, "Erro ao alocar memória.\n");
        exit(EXIT_FAILURE);
    }
    newNode->dado = dado;
    newNode->esq = NULL;
    newNode->dir = NULL;
    return newNode;
}

// Função para empilhar um nó
void push(stackNode **top, no *node) {
    stackNode *newNode = (stackNode*)malloc(sizeof(stackNode));
    if (newNode == NULL) {
        fprintf(stderr, "Erro ao alocar memória.\n");
        exit(EXIT_FAILURE);
    }
    newNode->node = node;
    newNode->next = *top;
    *top = newNode;
}

// Função para desempilhar um nó
no* pop(stackNode **top) {
    if (*top == NULL) {
        return NULL;
    }
    stackNode *temp = *top;
    *top = (*top)->next;
    no *poppedNode = temp->node;
    free(temp);
    return poppedNode;
}

// Função para verificar se a pilha está vazia
int isEmpty(stackNode *top) {
    return top == NULL;
}

// Função para percorrer a árvore em pós-ordem sem recursão
void pos_ordem(no *raiz) {
    if (raiz == NULL) {
        return;
    }

    stackNode *stack = NULL;
    no *current = raiz;
    no *lastVisited = NULL;

    while (!isEmpty(stack) || current != NULL) {
        if (current != NULL) {
            push(&stack, current);
            current = current->esq;
        } else {
            no *peekNode = stack->node;
            // Se a subárvore direita existe e não foi visitada
            if (peekNode->dir != NULL && lastVisited != peekNode->dir) {
                current = peekNode->dir;
            } else {
                printf("%d ", peekNode->dado);
                lastVisited = pop(&stack);
            }
        }
    }
}

