#include <stdio.h>

// Função auxiliar para inserir um elemento na posição correta
void insere(int *v, int n) {
    if (n <= 1) return;

    // Ordena os n-1 primeiros elementos
    insere(v, n-1);

    // Insere o n-ésimo elemento na posição correta
    int ultimo = v[n-1];
    int j = n-2;

    // Move os elementos maiores que o último para frente
    while (j >= 0 && v[j] > ultimo) {
        v[j+1] = v[j];
        j--;
    }
    v[j+1] = ultimo;
}

// Função principal para ordenar o vetor usando ordenação por inserção recursiva
void ordena(int *v, int n) {
    insere(v, n);
}


