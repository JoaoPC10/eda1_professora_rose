#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Estrutura para armazenar informações sobre as sequências
typedef struct {
    int length;
    char character;
    int position;
} Sequence;

// Função de comparação para ordenar as sequências
int compare(const void *a, const void *b) {
    Sequence *seqA = (Sequence *)a;
    Sequence *seqB = (Sequence *)b;

    if (seqA->length != seqB->length) {
        return seqB->length - seqA->length;  // Ordem decrescente por length
    } else {
        return seqA->position - seqB->position;  // Ordem crescente por position
    }
}

void ordena(int *v, int n) {
    // Implementação não necessária para o problema atual
}

int main() {
    char S[100001];
    scanf("%s", S);

    int len = strlen(S);
    Sequence sequences[100000];
    int seqCount = 0;

    // Percorrer a string e identificar as sequências contínuas
    for (int i = 0; i < len;) {
        char currentChar = S[i];
        int start = i;
        int count = 0;

        // Contar a sequência de caracteres iguais
        while (i < len && S[i] == currentChar) {
            i++;
            count++;
        }

        // Armazenar a sequência encontrada
        sequences[seqCount].length = count;
        sequences[seqCount].character = currentChar;
        sequences[seqCount].position = start;
        seqCount++;
    }

    // Ordenar as sequências
    qsort(sequences, seqCount, sizeof(Sequence), compare);

    // Imprimir as sequências ordenadas
    for (int i = 0; i < seqCount; i++) {
        printf("%d %c %d\n", sequences[i].length, sequences[i].character, sequences[i].position);
    }

    return 0;
}
