#include <stdio.h>

void coiso(int n){
        printf(".");
    for(int i=0; i<n; i++){
        printf("-");
    }
        printf("\n");

}

int regua(int n){
    if(n>0){
        regua(n-1);
            coiso(n);
                regua(n-1);
    }
}

int main(){
    int n;
    scanf("%d", &n);
    regua(n);
    return 0;
}