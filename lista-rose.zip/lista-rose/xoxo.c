#include <iostream>
#include <vector>

using namespace std;

// Estrutura para representar um nó da árvore de segmentos
struct SegmentTreeNode {
    int sum;
};

// Função para construir a árvore de segmentos recursivamente
void buildSegmentTree(vector<int>& arr, vector<SegmentTreeNode>& tree, int left, int right, int index) {
    if (left == right) {
        tree[index].sum = arr[left];
        return;
    }

    int mid = left + (right - left) / 2;
    buildSegmentTree(arr, tree, left, mid, 2 * index + 1);
    buildSegmentTree(arr, tree, mid + 1, right, 2 * index + 2);

    tree[index].sum = tree[2 * index + 1].sum + tree[2 * index + 2].sum;
}

// Função para consultar a soma em um intervalo
int query(vector<SegmentTreeNode>& tree, int start, int end, int left, int right, int index) {
    if (right < start || left > end) {
        return 0;
    }

    if (left >= start && right <= end) {
        return tree[index].sum;
    }

    int mid = left + (right - left) / 2;
    return query(tree, start, end, left, mid, 2 * index + 1) + query(tree, start, end, mid + 1, right, 2 * index + 2);
}

// Função para atualizar o valor de um elemento
void update(vector<SegmentTreeNode>& tree, int idx, int newValue, int left, int right, int index) {
    if (left == right) {
        tree[index].sum = newValue;
        return;
    }

    int mid = left + (right - left) / 2;
    if (idx <= mid) {
        update(tree, idx, newValue, left, mid, 2 * index + 1);
    } else {
        update(tree, idx, newValue, mid + 1, right, 2 * index + 2);
    }

    tree[index].sum = tree[2 * index + 1].sum + tree[2 * index + 2].sum;
}


