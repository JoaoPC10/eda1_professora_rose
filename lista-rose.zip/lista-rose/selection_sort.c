#include <stdio.h>
#include <stdlib.h>

// Função para realizar o Selection Sort
void selection_sort(int arr[], int n) {
    int i, j, min_idx, temp;
    // Move o limite da sublista não ordenada
    for (i = 0; i < n-1; i++) {
        // Encontra o menor elemento na sublista não ordenada
        min_idx = i;
        for (j = i+1; j < n; j++) {
            if (arr[j] < arr[min_idx]) {
                min_idx = j;
            }
        }
        // Troca o menor elemento encontrado com o primeiro elemento
        temp = arr[min_idx];
        arr[min_idx] = arr[i];
        arr[i] = temp;
    }
}

int main() {
    int numbers[1000];
    int n = 0;

    // Ler a entrada até EOF
    while (scanf("%d", &numbers[n]) != EOF) {
        n++;
    }

    // Ordenar o array usando Selection Sort
    selection_sort(numbers, n);

    // Imprimir o array ordenado
    for (int i = 0; i < n; i++) {
        if (i > 0) {
            printf(" ");
        }
        printf("%d", numbers[i]);
    }
    printf("\n");

    return 0;
}
