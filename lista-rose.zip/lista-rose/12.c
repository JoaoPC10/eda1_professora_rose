#include <stdio.h>
#include <stdlib.h>

typedef struct celula {
    int dado;
    struct celula *prox;
} celula;

int empilha(celula *p, int x) {
    celula *nova_celula = (celula*)malloc(sizeof(celula));
    if (nova_celula == NULL) {
        fprintf(stderr, "Erro: Falha na alocação de memória.\n");
        return 0; // Inserção mal sucedida
    }
    nova_celula->dado = x;
    nova_celula->prox = p->prox;
    p->prox = nova_celula;
    return 1; // Inserção bem sucedida
}
