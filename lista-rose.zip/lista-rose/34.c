#include <stdio.h>

#define ll long long

size_t bt1[200001], bt2[200001];
ll n, m;

ll rsq(ll i, ll* bt) {
    ll sum = 0;

    while (i >= 1) {
        sum += bt[i];
        i -= i & (-i);
    }

    return sum;
}

void add(size_t i, ll x, ll* bt) {
    while (i <= n) {
        bt[i] += x;
        i += i & (-i);
    }
}

ll rangeQuery(size_t i, size_t j) {
    return rsq(j, bt1) * j       - rsq(j, bt2) -
          (rsq(i-1, bt1) * (i-1) - rsq(i-1, bt2));
}

void rangeAdd(size_t i, size_t j, ll x) {
    add(i, x, bt1);         add(j+1, -x, bt1);
    add(i, x * (i-1), bt2); add(j + 1, -x * j, bt2);
}

int main() {
    scanf("%lld %lld", &n, &m);

    for (ll i = 1, x; i <= n; ++i) {
        scanf("%lld", &x);
        rangeAdd(i, i, x);
    }

    while (m--) {
        ll t, ka, xb;
        scanf("%lld %lld %lld", &t, &ka, &xb);

        if (t == 1)
            rangeAdd(ka, ka, -rangeQuery(ka, ka) + xb);
        else
            printf("%lld\n", rangeQuery(ka, xb));
    }
}