#include <stdio.h>
#include <stdlib.h>

// Definindo a estrutura de um nó da pilha
struct Node {
    int data;
    struct Node* next;
};

// Função para criar um novo nó da pilha
struct Node* newNode(int data) {
    struct Node* node = (struct Node*)malloc(sizeof(struct Node));
    if (!node) { // Checagem se a alocação de memória foi bem-sucedida
       
        exit(EXIT_FAILURE);
    }
    node->data = data;
    node->next = NULL;
    return node;
}

// Função para empilhar um novo elemento na pilha
void push(struct Node** top, int data) {
    struct Node* node = newNode(data);
    node->next = *top;
    *top = node;
}

int main() {
    int tamanhoMaximo = 100;
    int v[tamanhoMaximo];
    int contador = 0;
    int limiteSoma;

    struct Node* pilha = NULL;

   
    while (1) {
        int numero;
        scanf("%d", &numero);
        
        if (numero == 0 || contador == tamanhoMaximo)
            break;
        
        v[contador++] = numero;
    }

    
    scanf("%d", &limiteSoma);

    int soma = 0;
    for (int i = 0; i < contador; i++) {
        soma += v[i];
        if (soma > limiteSoma) {
            push(&pilha, v[i]); // Empilha o número atual
            soma = 0; // Reinicia a soma com o valor do número atual
        }
    }

    
    struct Node* temp = pilha;
    while (temp != NULL) {
        printf("%d\n", temp->data);
        temp = temp->next;
    }

    // Liberando a memória alocada para a pilha
    while (pilha != NULL) {
        struct Node* temp = pilha;
        pilha = pilha->next;
        free(temp);
    }

    return 0;
}