#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINES 100
#define MAX_CHARS 100000

typedef struct {
    char text[MAX_CHARS];
} Line;

typedef struct {
    char data[MAX_CHARS];
    int top;
} Stack;

void push(Stack *stack, char c) {
    stack->data[++stack->top] = c;
}

char pop(Stack *stack) {
    return stack->data[stack->top--];
}

char peek(Stack *stack) {
    return stack->data[stack->top];
}

int is_empty(Stack *stack) {
    return stack->top == -1;
}

int is_valid_format(Line *line) {
    Stack stack;
    stack.top = -1;

    for (int i = 0; i < strlen(line->text); i++) {
        char current = line->text[i];
        if (current == '*' || current == '/' || current == '_') {
            if (!is_empty(&stack) && stack.data[stack.top] == current) {
                pop(&stack);
            } else {
                push(&stack, current);
            }
        }
    }

    return is_empty(&stack);
}

int main() {
    int N;
    scanf("%d", &N);
    getchar(); // Consume newline character

    Line lines[MAX_LINES];
    for (int i = 0; i < N; i++) {
        fgets(lines[i].text, MAX_CHARS, stdin);
        lines[i].text[strcspn(lines[i].text, "\n")] = '\0'; // Remove newline character
    }

    char result = 'C';
    for (int i = 0; i < N; i++) {
        if (!is_valid_format(&lines[i])) {
            result = 'E';
            break;
        }
    }

    printf("%c\n", result);

    return 0;
}
