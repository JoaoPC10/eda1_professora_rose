#include <stdio.h>

int verificar(int tamanho, int *v, int limite, int i){
    int soma;

   
        soma += v[i];
        if(soma > limite){
            verificar(tamanho , v, limite, i+1);
            printf("%d\n", v[i]);
             soma = 0; 
        }
       
    
        return 0;
}


int main(){

    int numeros=-1;
     int v[2000000];
     int limite;
     int tamanho=0;
    int indice=0;
    int i =0;
     
    while(numeros!=0){
        printf("Digite os numeros que vao compor o vetor: ");
        scanf("%d", &numeros);

       v[indice] =  numeros;

       indice++;
       tamanho++;
    }
    printf("Limite da soma: ");
    scanf("%d", &limite);
    verificar(tamanho, v, limite, i);
    return 0;
}
