#include <stdio.h>

typedef struct celula {
    int dado;
    struct celula *prox;
} celula;

void divide_lista (celula *l, celula *l1, celula *l2){
   celula *p;
   p = l;
   
   while (p != NULL)
   if(p->dado  % 2 == 0){

   }
      p = p->prox; 
   return p;
}
//incompleta